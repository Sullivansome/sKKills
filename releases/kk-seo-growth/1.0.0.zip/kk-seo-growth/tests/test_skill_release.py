import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import zipfile


SCRIPT = Path(__file__).resolve().parents[1] / "scripts/skill_release.py"
spec = importlib.util.spec_from_file_location("skill_release", SCRIPT)
release = importlib.util.module_from_spec(spec)
spec.loader.exec_module(release)


class ReleaseTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.root = self.base / "skill"
        self.root.mkdir()
        (self.root / "VERSION").write_text("1.0.0\n")
        (self.root / "SKILL.md").write_text("original guidance\n")

    def test_identity_detects_content_and_path_changes_but_ignores_cache(self):
        original, _ = release.collect(self.root)
        cache = self.root / "__pycache__"
        cache.mkdir()
        (cache / "module.pyc").write_bytes(b"cache")
        self.assertEqual(original, release.collect(self.root)[0])
        (self.root / "SKILL.md").write_text("changed guidance\n")
        self.assertNotEqual(original["skill_sha256"], release.collect(self.root)[0]["skill_sha256"])
        (self.root / "note.txt").write_text("same bytes")
        before = release.collect(self.root)[0]
        (self.root / "note.txt").rename(self.root / "other.txt")
        self.assertNotEqual(before["skill_sha256"], release.collect(self.root)[0]["skill_sha256"])

    def test_snapshot_reproduces_bytes_manifest_and_original_identity(self):
        first, second = self.base / "first.zip", self.base / "second.zip"
        manifest = release.snapshot(self.root, first)
        release.snapshot(self.root, second)
        self.assertEqual(first.read_bytes(), second.read_bytes())
        with zipfile.ZipFile(first) as archive:
            saved = json.loads(archive.read("release.json"))
            self.assertEqual(manifest, saved)
            for name, digest in saved["files"].items():
                self.assertEqual(digest, hashlib.sha256(archive.read("kk-seo-growth/" + name)).hexdigest())
            restored = self.base / "restored"
            archive.extractall(restored)
        self.assertEqual(manifest, release.collect(restored / "kk-seo-growth")[0])
        (self.root / "SKILL.md").write_text("later edit")
        self.assertNotEqual(manifest, release.collect(self.root)[0])
        self.assertEqual(manifest, release.collect(restored / "kk-seo-growth")[0])

    def test_refuses_overwrite_and_destination_inside_package(self):
        archive = self.base / "release.zip"
        release.snapshot(self.root, archive)
        before = archive.read_bytes()
        with self.assertRaises(FileExistsError):
            release.snapshot(self.root, archive)
        self.assertEqual(before, archive.read_bytes())
        with self.assertRaises(ValueError):
            release.snapshot(self.root, self.root / "release.zip")

    def test_rejects_internal_symlinks_and_bad_version(self):
        (self.root / "linked.txt").symlink_to(self.root / "SKILL.md")
        with self.assertRaises(ValueError):
            release.collect(self.root)
        (self.root / "linked.txt").unlink()
        (self.root / "VERSION").write_text("not-a-version")
        with self.assertRaises(ValueError):
            release.collect(self.root)

    def test_cli_matches_library_and_reports_existing_destination(self):
        identity = subprocess.run([sys.executable, str(SCRIPT), "identity"], capture_output=True, text=True, check=True)
        self.assertEqual(release.collect(SCRIPT.parents[1])[0], json.loads(identity.stdout))
        target = self.base / "cli.zip"
        command = [sys.executable, str(SCRIPT), "snapshot", "--out", str(target)]
        subprocess.run(command, capture_output=True, text=True, check=True)
        retry = subprocess.run(command, capture_output=True, text=True)
        self.assertNotEqual(0, retry.returncode)
        self.assertIn("Release failed:", retry.stderr)


if __name__ == "__main__":
    unittest.main()
