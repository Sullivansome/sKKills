#!/usr/bin/env python3
"""Identify or snapshot this skill; no network, dependencies, or analytics access."""

import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import sys
import zipfile


ROOT = Path(__file__).resolve().parents[1]


def collect(root):
    root = Path(root).resolve()
    payload = {}
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root)
        if any(p in {"__pycache__", ".DS_Store", ".pytest_cache"} for p in relative.parts):
            continue
        if path.suffix == ".pyc":
            continue
        if path.is_symlink():
            raise ValueError(f"Internal symlinks are not supported: {relative}")
        if path.is_file():
            payload[relative.as_posix()] = path.read_bytes()
    version = payload["VERSION"].decode("utf-8").strip()
    if not re.fullmatch(r"(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)", version):
        raise ValueError("VERSION must contain major.minor.patch")
    if "SKILL.md" not in payload:
        raise ValueError("Missing SKILL.md")
    hashes = {name: hashlib.sha256(data).hexdigest() for name, data in payload.items()}
    canonical = json.dumps(hashes, sort_keys=True, separators=(",", ":")).encode("utf-8")
    manifest = {
        "schema_version": 1,
        "skill_name": "kk-seo-growth",
        "skill_version": version,
        "skill_sha256": hashlib.sha256(canonical).hexdigest(),
        "hash_method": "sha256 of UTF-8 JSON file-hash map, sorted keys, compact separators",
        "files": hashes,
    }
    return manifest, payload


def snapshot(root, destination):
    root = Path(root).resolve()
    destination = Path(destination).absolute()
    resolved = destination.resolve()
    if resolved == root or root in resolved.parents:
        raise ValueError("Store release archives outside the skill directory")
    manifest, payload = collect(root)
    # Build from the same bytes used for the fingerprint, with stable ZIP metadata.
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_STORED) as archive:
        files = {f"kk-seo-growth/{name}": data for name, data in payload.items()}
        files["release.json"] = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
        for name, data in sorted(files.items()):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("xb") as output:
        output.write(buffer.getvalue())
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("identity")
    release = commands.add_parser("snapshot")
    release.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    try:
        if args.command == "identity":
            manifest, _ = collect(ROOT)
        else:
            manifest = snapshot(ROOT, args.out)
        print(json.dumps(manifest, indent=2, sort_keys=True))
    except (OSError, ValueError, KeyError) as exc:
        parser.exit(1, f"Release failed: {exc}\n")


if __name__ == "__main__":
    main()
